/*
import React from "react";
import FoodItems from "./components/FoodItems";
import "bootstrap/dist/css/bootstrap.min.css";
import MyContainer from "./MyContainer";
import FoodInput from "./components/FoodInput";

const App = () => {
  let healthyfoods = [
    "Dal",
    "Vegetables",
    "Paneer",
    "Eggs",
    "Milk",
    "Rice",
    "DryFruits",
  ];

  return (
    <>
      <MyContainer>
        <h1>Helthy Food App</h1>
        <FoodInput />
        <FoodItems foodnames={healthyfoods} />
      </MyContainer>
    </>
  );
};

export default App;

*/

import React, { useState } from "react";
import FoodItems from "./components/FoodItems";
import "bootstrap/dist/css/bootstrap.min.css";
import MyContainer from "./components/MyContainer";
import FoodInput from "./components/FoodInput";

const App = () => {
  let healthyfoods = [
    "Dal",
    "Vegetables",
    "Paneer",
    "Eggs",
    "Milk",
    "Rice",
    "DryFruits",
  ];

  let foodValue = useState(); // return an array with 2 values.
  let foodText = foodValue[0]; // value
  let setFoodText = foodValue[1]; //setter fn to update the value received at index 0

  const getFoodName = (e) => {
    setFoodText(e.target.value);
  };

  return (
    <>
      <MyContainer>
        <h1>Helthy Food App</h1>
        <FoodInput handleInputEvent={getFoodName} />
        <p className="bg-secondary p-2 m-2 rounded text-bg-success">
          {foodText}
        </p>
        <FoodItems fooddata={healthyfoods} />
      </MyContainer>
    </>
  );
};

export default App;
