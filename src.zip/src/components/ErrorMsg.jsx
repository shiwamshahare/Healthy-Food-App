import React from "react";

const ErrorMsg = () => {
  return (
    <>
      <h3 className="text-secondary">I'm Still Hungry</h3>
    </>
  );
};

export default ErrorMsg;
