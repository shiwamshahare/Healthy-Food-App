/*
import React from "react";
import css from "./FoodInput.module.css";

const FoodInput = () => {
  const handleInput = (e) => {
    const value = e.target.value;
    console.log(value);
  };
  return (
    <>
      <input
        type="text"
        placeholder="Enter Food Item"
        onChange={handleInput}
        className={css["food-input"]}
      />
    </>
  );
};

export default FoodInput;
*/

import React from "react";
import css from "./FoodInput.module.css";

const FoodInput = ({ handleInputEvent }) => {
  return (
    <>
      <input
        type="text"
        placeholder="Enter Food Item"
        onChange={handleInputEvent}
        className={css["food-input"]}
      />
    </>
  );
};

export default FoodInput;
