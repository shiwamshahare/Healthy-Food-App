// import React from "react";

// const fooditemss = ({ fooditems }) => {
//   function handleBuyBtn(e) {
//     console.log(fooditems + " is being baught");
//   }

//   return (
//     <>
//       <li className="list-group-items text-dark d-flex justify-content-between bg-light bg-gradient">
//         <span>{fooditems}</span>
//         <button
//           className="rounded btn btn-secondary "
//           onClick={(event) => {
//             handleBuyBtn(event);
//           }}
//         >
//           Buy
//         </button>
//       </li>
//     </>
//   );
// };
// onabort;

// export default fooditemss;

// Receiving fn passed from parent and communicating back when button is clicked

import React from "react";

const Items = ({ fooditems, handleBuyBtn }) => {
  return (
    <>
      <li className="list-group-item text-dark d-flex justify-content-between bg-light bg-gradient">
        <span>{fooditems}</span>
        <button className="rounded btn btn-secondary " onClick={handleBuyBtn}>
          Buy
        </button>
      </li>
    </>
  );
};

export default Items;
